﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace SignatureSampleCode
{
    public partial class IPN_Listenner : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string NotifyMessage = Request.Form.Get("NotifyData");
                //NotifyMessage = "<?xml version=\"1.0\"?><PayooConnectionPackage xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><Data>PFBheW1lbnROb3RpZmljYXRpb24+PHNob3BzPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzaG9wPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c2Vzc2lvbj45MDI1NTI4NjE8L3Nlc3Npb24+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1c2VybmFtZT5zaG9wZGVtb19jaGVja3N1bTwvdXNlcm5hbWU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzaG9wX2lkPjU5MDwvc2hvcF9pZD4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNob3BfdGl0bGU+U2hvcERlbW88L3Nob3BfdGl0bGU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzaG9wX2RvbWFpbj5odHRwOi8vbG9jYWxob3N0PC9zaG9wX2RvbWFpbj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNob3BfYmFja191cmw+aHR0cDovL1Nob3BEZW1vL1RoYW5rWW91LmFzcHg8L3Nob3BfYmFja191cmw+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcmRlcl9ubz45MDI1NTI4NjE8L29yZGVyX25vPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3JkZXJfY2FzaF9hbW91bnQ+MTAwMDA8L29yZGVyX2Nhc2hfYW1vdW50PgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3JkZXJfc2hpcF9kYXRlPjE5LzA0LzIwMTc8L29yZGVyX3NoaXBfZGF0ZT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9yZGVyX3NoaXBfZGF5cz4xPC9vcmRlcl9zaGlwX2RheXM+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcmRlcl9kZXNjcmlwdGlvbj4lM2N0YWJsZSt3aWR0aCUzZCUyNzEwMCUyNSUyNytib3JkZXIlM2QlMjcxJTI3K2NlbGxzcGFjaW5nJTNkJTI3MCUyNyUzZSUzY3RoZWFkJTNlJTNjdHIlM2UlM2N0ZCt3aWR0aCUzZCUyNzQwJTI1JTI3K2FsaWduJTNkJTI3Y2VudGVyJTI3JTNlJTNjYiUzZVQlYzMlYWFuK2glYzMlYTBuZyUzYyUyZmIlM2UlM2MlMmZ0ZCUzZSUzY3RkK3dpZHRoJTNkJTI3MjAlMjUlMjcrYWxpZ24lM2QlMjdjZW50ZXIlMjclM2UlM2NiJTNlJWM0JTkwJWM2JWExbitnaSVjMyVhMSUzYyUyZmIlM2UlM2MlMmZ0ZCUzZSUzY3RkK3dpZHRoJTNkJTI3MTUlMjUlMjcrYWxpZ24lM2QlMjdjZW50ZXIlMjclM2UlM2NiJTNlUyVlMSViYiU5MStsJWM2JWIwJWUxJWJiJWEzbmclM2MlMmZiJTNlJTNjJTJmdGQlM2UlM2N0ZCt3aWR0aCUzZCUyNzI1JTI1JTI3K2FsaWduJTNkJTI3Y2VudGVyJTI3JTNlJTNjYiUzZVRoJWMzJWEwbmgrdGklZTElYmIlODFuJTNjJTJmYiUzZSUzYyUyZnRkJTNlJTNjJTJmdHIlM2UlM2MlMmZ0aGVhZCUzZSUzY3Rib2R5JTNlJTNjdHIlM2UlM2N0ZCthbGlnbiUzZCUyN2xlZnQlMjclM2VIUCtQYXZpbGlvbitEVjMtMzUwMlRYJTNjJTJmdGQlM2UlM2N0ZCthbGlnbiUzZCUyN3JpZ2h0JTI3JTNlMjMlMmMwMDAlM2MlMmZ0ZCUzZSUzY3RkK2FsaWduJTNkJTI3Y2VudGVyJTI3JTNlMSUzYyUyZnRkJTNlJTNjdGQrYWxpZ24lM2QlMjdyaWdodCUyNyUzZTIzJTJjMDAwJTNjJTJmdGQlM2UlM2MlMmZ0ciUzZSUzY3RyJTNlJTNjdGQrYWxpZ24lM2QlMjdsZWZ0JTI3JTNlRkFOK05vdGVib29rKyhCNCklM2MlMmZ0ZCUzZSUzY3RkK2FsaWduJTNkJTI3cmlnaHQlMjclM2UxMCUyYzAwMCUzYyUyZnRkJTNlJTNjdGQrYWxpZ24lM2QlMjdjZW50ZXIlMjclM2UxJTNjJTJmdGQlM2UlM2N0ZCthbGlnbiUzZCUyN3JpZ2h0JTI3JTNlMTAlMmMwMDAlM2MlMmZ0ZCUzZSUzYyUyZnRyJTNlJTNjdHIlM2UlM2N0ZCthbGlnbiUzZCUyN3JpZ2h0JTI3K2NvbHNwYW4lM2QlMjczJTI3JTNlJTNjYiUzZVQlZTElYmIlOTVuZyt0aSVlMSViYiU4MW4lM2ElM2MlMmZiJTNlJTNjJTJmdGQlM2UlM2N0ZCthbGlnbiUzZCUyN3JpZ2h0JTI3JTNlNDMlMmMwMDAlM2MlMmZ0ZCUzZSUzYyUyZnRyJTNlJTNjdHIlM2UlM2N0ZCthbGlnbiUzZCUyN2xlZnQlMjcrY29sc3BhbiUzZCUyNzQlMjclM2VTb21lK25vdGVzK2Zvcit0aGUrb3JkZXIlM2MlMmZ0ZCUzZSUzYyUyZnRyJTNlJTNjJTJmdGJvZHklM2UlM2MlMmZ0YWJsZSUzZTwvb3JkZXJfZGVzY3JpcHRpb24+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxub3RpZnlfdXJsPmh0dHBzOi8vU2hvcERlbW8vTm90aWZ5LmFzbXg8L25vdGlmeV91cmw+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx2YWxpZGl0eV90aW1lPjIwMTcwNDIwMTU0MDAxPC92YWxpZGl0eV90aW1lPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Y3VzdG9tZXI+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxuYW1lPkR1eS5UaGFpPC9uYW1lPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGhvbmU+MDkwMzExNzA1NTwvcGhvbmU+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhZGRyZXNzPjEwMTEgLSBkaWEgY2hpIG5oYTwvYWRkcmVzcz4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGNpdHk+NjAwMDA8L2NpdHk+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxlbWFpbD52dS5uZ3V5ZW5AdmlkaWVudHUudm48L2VtYWlsPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2N1c3RvbWVyPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2hvcD4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2hvcHM+PFN0YXRlPlBBWU1FTlRfUkVDRUlWRUQ8L1N0YXRlPjxQYXltZW50TWV0aG9kPkVfV0FMTEVUPC9QYXltZW50TWV0aG9kPjwvUGF5bWVudE5vdGlmaWNhdGlvbj4=</Data><Signature>161F015A91A24D9F5B9DDA92674FB73F1F34CF77476166C747DE54C3D5F222B978488F4DBE387ADBDB853AEAE9A5DE3183E50112F7E93CEE4C2BEB5C67892CAE</Signature><PayooSessionID>skQ1IWQkbnNmzzSx0HYm9jSPqYesiu7gqoYfEwlNMdNJXl71J9PnkKhTwdd53798urqO8oTVdFIqkuUg/D95ZA==</PayooSessionID><KeyFields>PaymentMethod|State|Session|BusinessUsername|ShopID|ShopTitle|ShopDomain|ShopBackUrl|OrderNo|OrderCashAmount|StartShippingDate|ShippingDays|OrderDescription|NotifyUrl|PaymentExpireDate</KeyFields></PayooConnectionPackage>";

                if (NotifyMessage == null || "".Equals(NotifyMessage))
                {
                    return;
                }

                PayooConnectionPackage NotifyPackage = GetPayooConnectionPackage(NotifyMessage);
                Payoo.Lib.CmsCryptography objCms = new Payoo.Lib.CmsCryptography();
                if (objCms.Verify(NotifyPackage.Data, NotifyPackage.Signature))
                {
                    PaymentNotification invoice = GetPaymentNotify(NotifyPackage.Data);

                    if (invoice.State.Equals("PAYMENT_RECEIVED", StringComparison.OrdinalIgnoreCase))
                    {
                        // update order 
                        // to do.....
                        Response.Clear();
                        Response.Output.Write("NOTIFY_RECEIVED");
                        Response.End();
                    }
                }
                else
                {
                    Response.Clear();
                    Response.Output.Write("Verified signature is faillure!");
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        
        }


        public PayooConnectionPackage GetPayooConnectionPackage(string strPackage)
        {
            try
            {
                string PackageData = strPackage;
                PayooConnectionPackage objPackage = new PayooConnectionPackage();
                XmlDocument Doc = new XmlDocument();
                Doc.LoadXml(PackageData);
                objPackage.Data = ReadNodeValue(Doc, "Data");
                objPackage.Signature = ReadNodeValue(Doc, "Signature");
                return objPackage;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public PaymentNotification GetPaymentNotify(string NotifyData)
        {
            try
            {
                string Data = Encoding.UTF8.GetString(Convert.FromBase64String(NotifyData));
                PaymentNotification invoice = new PaymentNotification();
                XmlDocument Doc = new XmlDocument();
                Doc.LoadXml(Data);
                if (!string.IsNullOrEmpty(ReadNodeValue(Doc, "BillingCode")))
                {
                    // Pay at store
                    if (!string.IsNullOrEmpty(ReadNodeValue(Doc, "ShopId")))
                    {
                        invoice.ShopID = long.Parse(ReadNodeValue(Doc, "ShopId"));
                    }
                    invoice.OrderNo = ReadNodeValue(Doc, "OrderNo");
                    if (!string.IsNullOrEmpty(ReadNodeValue(Doc, "OrderCashAmount")))
                    {
                        invoice.OrderCashAmount = long.Parse(ReadNodeValue(Doc, "OrderCashAmount"));
                    }
                    invoice.State = ReadNodeValue(Doc, "State");
                    invoice.PaymentMethod = ReadNodeValue(Doc, "PaymentMethod");
                    invoice.BillingCode = ReadNodeValue(Doc, "BillingCode");
                    invoice.PaymentExpireDate = ReadNodeValue(Doc, "PaymentExpireDate");
                }
                else
                {
                    invoice.Session = ReadNodeValue(Doc, "session");
                    invoice.BusinessUsername = ReadNodeValue(Doc, "username");
                    invoice.ShopID = long.Parse(ReadNodeValue(Doc, "shop_id"));
                    invoice.ShopTitle = ReadNodeValue(Doc, "shop_title");
                    invoice.ShopDomain = ReadNodeValue(Doc, "shop_domain");
                    invoice.ShopBackUrl = ReadNodeValue(Doc, "shop_back_url");
                    invoice.OrderNo = ReadNodeValue(Doc, "order_no");
                    invoice.OrderCashAmount = long.Parse(ReadNodeValue(Doc, "order_cash_amount"));
                    invoice.StartShippingDate = ReadNodeValue(Doc, "order_ship_date");
                    invoice.ShippingDays = short.Parse(ReadNodeValue(Doc, "order_ship_days"));
                    invoice.OrderDescription = System.Web.HttpUtility.UrlDecode((ReadNodeValue(Doc, "order_description")));
                    invoice.NotifyUrl = ReadNodeValue(Doc, "notify_url");
                    invoice.State = ReadNodeValue(Doc, "State");
                    invoice.PaymentMethod = ReadNodeValue(Doc, "PaymentMethod");
                    invoice.PaymentExpireDate = ReadNodeValue(Doc, "validity_time");
                }
                return invoice;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string ReadNodeValue(XmlDocument Doc, string TagName)
        {
            XmlNodeList nodeList = Doc.GetElementsByTagName(TagName);
            string NodeValue = null;
            if (nodeList.Count > 0)
            {
                XmlNode node = nodeList.Item(0);
                NodeValue = (node == null) ? "" : node.InnerText;
            }
            return NodeValue == null ? "" : NodeValue;
        }
    }


}