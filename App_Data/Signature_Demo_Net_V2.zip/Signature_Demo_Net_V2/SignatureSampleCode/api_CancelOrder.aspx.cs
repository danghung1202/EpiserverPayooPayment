﻿using RestSharp;
using SignatureSampleCode;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SignatureSampleCode
{
    public partial class api_CancelOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancelOrder_Click(object sender, EventArgs e)
        {
            CancelOrder objRequest = new CancelOrder();
            objRequest.ShopID = ConfigurationManager.AppSettings["ShopID"];
            objRequest.OrderID = txtOrderNo.Text.Trim();
            objRequest.NewStatus = "3"; // Status of canceling
            objRequest.UpdateLog = "Business cancel this order.";

            JavaScriptSerializer objJson = new JavaScriptSerializer();
            CallAPI callAPI = new CallAPI();
            lbResult.Text = callAPI.Caller("CancelOrder", objJson.Serialize(objRequest));

        }

    }
}