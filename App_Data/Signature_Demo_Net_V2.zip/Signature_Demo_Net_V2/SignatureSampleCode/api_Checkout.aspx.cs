﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Security.Cryptography;
using System.Text;
using System.Net;
using System.IO;
using RestSharp;
using System.Web.Script.Serialization;

namespace SignatureSampleCode
{
    public partial class Checkout : System.Web.UI.Page
    {
        public string XML = "";
        public string Checksum = "";
        public string ProviderUrl = ConfigurationManager.AppSettings["ApiPayooCheckout"].ToString();
        public long ShopId = long.Parse(ConfigurationManager.AppSettings["ShopID"]);
        public string ShopDomain = ConfigurationManager.AppSettings["ShopDomain"];
        public string BusinessUsername = ConfigurationManager.AppSettings["BusinessUsername"];


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public static string EncryptSHA512(string input)
        {
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(input);
            using (SHA512 hash = System.Security.Cryptography.SHA512.Create())
            {
                byte[] hashedInputBytes = hash.ComputeHash(bytes);

                // Convert to text
                // StringBuilder Capacity is 128, because 512 bits / 8 bits in byte * 2 symbols for byte 
                StringBuilder hashedInputStringBuilder = new System.Text.StringBuilder(128);
                foreach (byte b in hashedInputBytes)
                {
                    hashedInputStringBuilder.Append(b.ToString("X2"));
                }
                return hashedInputStringBuilder.ToString();
            }
        }
        protected void btnCheckOut_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            string orderId = r.Next().ToString();

            PayooOrder order = new PayooOrder();
            order.Session = orderId;
            order.BusinessUsername = ConfigurationManager.AppSettings["BusinessUsername"];
            order.OrderCashAmount = 10000;
            order.OrderNo = orderId;
            order.ShippingDays = short.Parse(ConfigurationManager.AppSettings["ShippingDays"]);
            order.ShopBackUrl = ConfigurationManager.AppSettings["ShopBackUrl"];
            order.ShopDomain = ConfigurationManager.AppSettings["ShopDomain"];
            order.ShopID = long.Parse(ConfigurationManager.AppSettings["ShopID"]);
            order.ShopTitle = ConfigurationManager.AppSettings["ShopTitle"];
            order.StartShippingDate = DateTime.Now.ToString("dd/MM/yyyy");
            order.NotifyUrl = ConfigurationManager.AppSettings["NotifyUrl"];
            order.ValidityTime = DateTime.Now.AddDays(1).ToString("yyyyMMddHHmmss");
            // thong tin khach hang
            order.CustomerName = "test & test";//ConfigurationManager.AppSettings["CustomerName"];
            order.CustomerPhone = ConfigurationManager.AppSettings["CustomerPhone"];
            order.CustomerEmail = ConfigurationManager.AppSettings["CustomerEmail"];
            order.CustomerAddress = ConfigurationManager.AppSettings["CustomerAddress"];
            order.CustomerCity = ConfigurationManager.AppSettings["CustomerCity"]; // ninh thuan
            //You can do
            order.OrderDescription = HttpUtility.UrlEncode("<table width='100%' border='1' cellspacing='0'><thead><tr><td width='40%' align='center'><b>Tên hàng</b></td><td width='20%' align='center'><b>Đơn giá</b></td><td width='15%' align='center'><b>Số lượng</b></td><td width='25%' align='center'><b>Thành tiền</b></td></tr></thead><tbody><tr><td align='left'>HP Pavilion DV3-3502TX</td><td align='right'>23,000</td><td align='center'>1</td><td align='right'>23,000</td></tr><tr><td align='left'>FAN Notebook (B4)</td><td align='right'>10,000</td><td align='center'>1</td><td align='right'>10,000</td></tr><tr><td align='right' colspan='3'><b>Tổng tiền:</b></td><td align='right'>43,000</td></tr><tr><td align='left' colspan='4'>Some notes for the order</td></tr></tbody></table>");

            Checksum = string.Empty;

            //Su dung checksum ko ma hoa du lieu
            string ChecksumKey = ConfigurationManager.AppSettings["ChecksumKey"];
            XML = PaymentXMLFactory.GetPaymentXML(order);
            Checksum = EncryptSHA512(ChecksumKey + XML);


            var client = new RestClient(ProviderUrl);
            var request = new RestRequest(Method.POST);
            request.AddHeader("content-type", "multipart/form-data");
            request.AddParameter("data", XML);
            request.AddParameter("checksum", Checksum);
            request.AddParameter("refer", ShopDomain);
            IRestResponse response = client.Execute(request);
            if(response.StatusCode == HttpStatusCode.OK)
            {
                JavaScriptSerializer objJson = new JavaScriptSerializer();
                CreateOrderResponse objResponse = objJson.Deserialize<CreateOrderResponse>(response.Content);
                if(objResponse.result.Equals("success",StringComparison.OrdinalIgnoreCase))
                {
                    Response.Redirect(objResponse.order.payment_url);
                }
            }
        }
    }
}