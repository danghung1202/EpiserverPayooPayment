﻿using RestSharp;
using SignatureSampleCode;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SignatureSampleCode
{
    public partial class api_CreateBillingCode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CreateBillingCode();
        }

        public static List<long> ListFilesRunning = new List<long>();
        private void CreateBillingCode()
        {
            CreateBillingCodeRequest objRequest = new CreateBillingCodeRequest();
            objRequest.ShopID = ConfigurationManager.AppSettings["ShopID"];
            objRequest.OrderNo = "PR_ORD_" + DateTime.Now.ToString("yyyyMMddHHmmss");
            objRequest.CyberCash = "50000";
            DateTime dtExpire = DateTime.Now.AddHours(3);
            objRequest.PaymentExpireDate = dtExpire.ToString("yyyyMMddHHmmss");
            objRequest.FromShipDate = DateTime.Now.ToString("dd/MM/yyyy");
            objRequest.ShipNumDay = "1";
            objRequest.Description = "Đơn hàng: " + objRequest.OrderNo + " Thanh toán cho dịch vụ/ chương trình/ chuyến đi..... Số tiền thanh toán: " + objRequest.CyberCash;
            objRequest.InfoEx = HttpUtility.UrlEncode("<InfoEx><CustomerPhone>09022333556</CustomerPhone><CustomerEmail>mail@gmail.com</CustomerEmail><Title>Test title</Title></InfoEx>");
            objRequest.NotifyUrl = ConfigurationManager.AppSettings["NotifyUrl"];

            JavaScriptSerializer objJson = new JavaScriptSerializer();
            CallAPI callAPI = new CallAPI();
            CreateBillingCodeResponse objResponse = objJson.Deserialize<CreateBillingCodeResponse>(callAPI.Caller("getbillingcode", objJson.Serialize(objRequest)));
            if (objResponse.ResponseCode == "0")
            {
                lbResult.Text = "Your billing code is: <strong>" + objResponse.BillingCode + "</strong>. Please, pay it before: <strong>" + dtExpire.ToString("dd/MM/yyyy HH:mm:ss") + "</strong>";
            }
            else
            {
                lbResult.Text = "Call api get billing code is faillure! Return code: " + objResponse.ResponseCode;
            }
            
        }
    }
}