﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Web.Script.Serialization;
using System.Xml.Serialization;

namespace SignatureSampleCode
{
    public class CallAPI
    {
        public string Caller(string strAPIName, string strRequestData)
        {
            try
            {
                System.Net.ServicePointManager.CertificatePolicy = new CertPolicy();
                var client = new RestClient(ConfigurationManager.AppSettings["UrlPayooAPI"] + "/" + strAPIName);
                var request = new RestRequest(Method.POST);

                #region set header request
                request.AddHeader("apiusername", ConfigurationManager.AppSettings["APIUsername"]);
                request.AddHeader("apipassword", ConfigurationManager.AppSettings["APIPassword"]);
                request.AddHeader("apisignature", ConfigurationManager.AppSettings["APISignature"]);
                request.AddHeader("content-type", "application/json");
                #endregion

                #region build and sign data request
                APIRequest objAPIRequest = new APIRequest();
                objAPIRequest.RequestData = strRequestData;
                // sign data
                Payoo.Lib.CmsCryptography objCms = new Payoo.Lib.CmsCryptography();
                objAPIRequest.Signature = objCms.Sign(objAPIRequest.RequestData);
                #endregion

                // set body request
                JavaScriptSerializer objJson = new JavaScriptSerializer();
                request.AddParameter("application/json", objJson.Serialize(objAPIRequest), ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {

                    APIResponse objAPIResponse = objJson.Deserialize<APIResponse>(response.Content);
                    if (objCms.Verify(objAPIResponse.ResponseData, objAPIResponse.Signature))
                    {
                        return objAPIResponse.ResponseData;
                    }
                    else
                    {
                        throw new Exception("Invalid signature!");
                    }

                }
                else
                {
                    throw new Exception("response.StatusCode: " + response.StatusCode + "</br>" + response.ErrorMessage);
                }

            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }

    class CertPolicy : ICertificatePolicy
    {
        public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem)
        {
            return true;
        }
    }
}