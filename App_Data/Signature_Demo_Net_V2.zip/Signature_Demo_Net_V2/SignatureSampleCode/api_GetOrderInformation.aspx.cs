﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SignatureSampleCode
{
    public partial class GetOrderInformation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        
        protected void btn_apiGetOrderInfo_Click(object sender, EventArgs e)
        {
            GetOrderInfoRequest objGetOrder = new GetOrderInfoRequest();
            objGetOrder.OrderId = txtOrderNo.Text.Trim();  //"171013143523760" 
            objGetOrder.ShopId = ConfigurationManager.AppSettings["ShopID"];

            JavaScriptSerializer objJson = new JavaScriptSerializer();
            CallAPI callAPI = new CallAPI();
            lbResult.Text = callAPI.Caller("getorderinfo", objJson.Serialize(objGetOrder));
        }
    }
}